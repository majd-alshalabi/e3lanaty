<?php

namespace App\Models\constant;


class Constant 
{
    public const NUM_OF_PAGE = 10;
    public const NOTIFICATION_DEFAULT_TYPE = 0;

    public const SERVER_KEY = 'AAAA2G_ymwQ:APA91bGp1jkxeHRBIQp18Nx_KrvqydQH8_-3ku_bTgNyDURWVavC1SShq5np1knqJaD6qiMYq1stHcV1ot417HljTsq4tFbe_OVzuOHNmsTMxU-Zs-WMTwePQTDnVMcrTos6BlfluA0I';
}