<?php
namespace App\Models\Sanctum; // place your file to Models/Sanctum/PersonalAccessToken.php

use Laravel\Sanctum\PersonalAccessToken as SanctumPersonalAccessToken;

class PersonalAccessToken extends SanctumPersonalAccessToken
{
    // ...
}